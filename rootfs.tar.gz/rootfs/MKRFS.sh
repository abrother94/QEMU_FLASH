#!/bin/sh
find * -print | cpio -o -H newc | gzip > ../arm_root1-3.X.img

