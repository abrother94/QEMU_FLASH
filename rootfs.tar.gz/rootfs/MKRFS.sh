#!/bin/sh
find * -print | cpio -o -H newc | gzip > ../arm_root.img

